namespace ExpertFinderWeb.Data.Entities.Model
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;

    public partial class ExpertFinderWebContext : DbContext
    {
        public ExpertFinderWebContext()
            : base("name=ExpertFinderWebContext")
        {
        }

        public virtual DbSet<Expert> Expert { get; set; }
        public virtual DbSet<ExpertSkills> ExpertSkills { get; set; }
        public virtual DbSet<ExpertSubSkills> ExpertSubSkills { get; set; }
        public virtual DbSet<Skills> Skills { get; set; }
        public virtual DbSet<SubSkills> SubSkills { get; set; }
        public virtual DbSet<User> User { get; set; }
        public virtual DbSet<UserCommentsOnExperts> UserCommentsOnExperts { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<User>()
                .Property(e => e.IsActive)
                .IsFixedLength();
        }
    }
}
