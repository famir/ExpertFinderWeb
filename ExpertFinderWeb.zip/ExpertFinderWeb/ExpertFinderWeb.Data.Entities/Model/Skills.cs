namespace ExpertFinderWeb.Data.Entities.Model
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class Skills
    {
        [Key]
        public int SkillId { get; set; }

        [Required]
        [StringLength(250)]
        public string SkillTitle { get; set; }

        public bool IsActive { get; set; }
    }
}
