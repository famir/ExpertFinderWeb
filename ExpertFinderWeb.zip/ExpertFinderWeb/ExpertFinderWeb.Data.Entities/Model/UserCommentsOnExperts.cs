namespace ExpertFinderWeb.Data.Entities.Model
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class UserCommentsOnExperts
    {
        [Key]
        public int CommentId { get; set; }

        public int UserId { get; set; }

        [Required]
        public string Comment { get; set; }

        public int ExpertId { get; set; }

        public DateTime DateTime { get; set; }
    }
}
