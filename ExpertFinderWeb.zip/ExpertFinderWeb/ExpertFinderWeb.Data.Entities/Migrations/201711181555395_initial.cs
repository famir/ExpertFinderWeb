namespace ExpertFinderWeb.Data.Entities.Migrations
{
    using System;
    using System.Data.Entity.Migrations;

    public partial class initial : DbMigration
    {
        public override void Up()
        {
            //CreateTable(
            //    "dbo.Expert",
            //    c => new
            //    {
            //        ExpertId = c.Int(nullable: false, identity: true),
            //        FirstName = c.String(maxLength: 50),
            //        LastName = c.String(nullable: false, maxLength: 50),
            //        AccountName = c.String(nullable: false, maxLength: 50),
            //        Tags = c.String(nullable: false),
            //        Title = c.String(maxLength: 50),
            //        City = c.String(maxLength: 100),
            //        Country = c.String(maxLength: 50),
            //        Email = c.String(nullable: false, maxLength: 50),
            //        Password = c.String(nullable: false, maxLength: 50),
            //        Phone = c.String(maxLength: 50),
            //        Position = c.String(maxLength: 50),
            //        Department = c.String(maxLength: 250),
            //        DateTime = c.DateTime(nullable: false),
            //        IsActive = c.Boolean(nullable: false),
            //    })
            //    .PrimaryKey(t => t.ExpertId);

            //CreateTable(
            //    "dbo.ExpertSkills",
            //    c => new
            //    {
            //        ExpertSkillId = c.Int(nullable: false, identity: true),
            //        SkillId = c.Int(nullable: false),
            //        ExpertId = c.Int(nullable: false),
            //    })
            //    .PrimaryKey(t => t.ExpertSkillId);

            //CreateTable(
            //    "dbo.ExpertSubSkills",
            //    c => new
            //    {
            //        ExpertSubSkillId = c.Int(nullable: false, identity: true),
            //        ExpertId = c.Int(nullable: false),
            //        SubSkillId = c.Int(nullable: false),
            //    })
            //    .PrimaryKey(t => t.ExpertSubSkillId);

            //CreateTable(
            //    "dbo.Skills",
            //    c => new
            //    {
            //        SkillId = c.Int(nullable: false, identity: true),
            //        SkillTitle = c.String(nullable: false, maxLength: 250),
            //        IsActive = c.Boolean(nullable: false),
            //    })
            //    .PrimaryKey(t => t.SkillId);

            //CreateTable(
            //    "dbo.SubSkills",
            //    c => new
            //    {
            //        SubSkillId = c.Int(nullable: false, identity: true),
            //        SubSkillTitle = c.String(nullable: false, maxLength: 250),
            //        SkillId = c.Int(nullable: false),
            //        IsActive = c.Boolean(nullable: false),
            //    })
            //    .PrimaryKey(t => t.SubSkillId);

            //CreateTable(
            //    "dbo.User",
            //    c => new
            //    {
            //        UserId = c.Int(nullable: false, identity: true),
            //        UserName = c.String(nullable: false, maxLength: 50),
            //        Email = c.String(nullable: false, maxLength: 50),
            //        Password = c.String(nullable: false, maxLength: 50),
            //        DateTime = c.DateTime(nullable: false),
            //        IsActive = c.String(nullable: false, maxLength: 10, fixedLength: true),
            //    })
            //    .PrimaryKey(t => t.UserId);

            //CreateTable(
            //    "dbo.UserCommentsOnExperts",
            //    c => new
            //    {
            //        CommentId = c.Int(nullable: false, identity: true),
            //        UserId = c.Int(nullable: false),
            //        Comment = c.String(nullable: false),
            //        ExpertId = c.Int(nullable: false),
            //        DateTime = c.DateTime(nullable: false),
            //    })
            //    .PrimaryKey(t => t.CommentId);

        }

        public override void Down()
        {
            //DropTable("dbo.UserCommentsOnExperts");
            //DropTable("dbo.User");
            //DropTable("dbo.SubSkills");
            //DropTable("dbo.Skills");
            //DropTable("dbo.ExpertSubSkills");
            //DropTable("dbo.ExpertSkills");
            //DropTable("dbo.Expert");
        }
    }
}
