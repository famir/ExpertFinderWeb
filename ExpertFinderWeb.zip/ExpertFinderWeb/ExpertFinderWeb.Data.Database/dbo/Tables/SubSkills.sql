﻿CREATE TABLE [dbo].[SubSkills] (
    [SubSkillId]    INT            IDENTITY (1, 1) NOT NULL,
    [SubSkillTitle] NVARCHAR (250) NOT NULL,
    [SkillId]       INT            NOT NULL,
    [IsActive]      BIT            NOT NULL,
    CONSTRAINT [PK_SubSkill] PRIMARY KEY CLUSTERED ([SubSkillId] ASC)
);

