﻿CREATE TABLE [dbo].[UserCommentsOnExperts] (
    [CommentId] INT            IDENTITY (1, 1) NOT NULL,
    [UserId]    INT            NOT NULL,
    [Comment]   NVARCHAR (MAX) NOT NULL,
    [ExpertId]  INT            NOT NULL,
    [DateTime]  DATETIME       NOT NULL,
    CONSTRAINT [PK_UserCommentsOnExperts] PRIMARY KEY CLUSTERED ([CommentId] ASC)
);

