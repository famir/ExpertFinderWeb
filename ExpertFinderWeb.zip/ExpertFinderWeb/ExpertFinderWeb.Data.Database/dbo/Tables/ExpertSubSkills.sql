﻿CREATE TABLE [dbo].[ExpertSubSkills] (
    [ExpertSubSkillId] INT IDENTITY (1, 1) NOT NULL,
    [ExpertId]         INT NOT NULL,
    [SubSkillId]       INT NOT NULL,
    CONSTRAINT [PK_ExpertSubSkill] PRIMARY KEY CLUSTERED ([ExpertSubSkillId] ASC)
);

