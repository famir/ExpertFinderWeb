﻿CREATE TABLE [dbo].[ExpertSkills] (
    [ExpertSkillId] INT IDENTITY (1, 1) NOT NULL,
    [SkillId]       INT NOT NULL,
    [ExpertId]      INT NOT NULL,
    CONSTRAINT [PK_Table_1] PRIMARY KEY CLUSTERED ([ExpertSkillId] ASC)
);

