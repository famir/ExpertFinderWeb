﻿CREATE TABLE [dbo].[Skills] (
    [SkillId]    INT            IDENTITY (1, 1) NOT NULL,
    [SkillTitle] NVARCHAR (250) NOT NULL,
    [IsActive]   BIT            NOT NULL,
    CONSTRAINT [PK_Skills] PRIMARY KEY CLUSTERED ([SkillId] ASC)
);

