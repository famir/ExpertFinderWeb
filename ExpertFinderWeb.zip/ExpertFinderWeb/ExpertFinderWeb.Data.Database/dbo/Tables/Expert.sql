﻿CREATE TABLE [dbo].[Expert] (
    [ExpertId]    INT            IDENTITY (1, 1) NOT NULL,
    [FirstName]   NVARCHAR (50)  NULL,
    [LastName]    NVARCHAR (50)  NOT NULL,
    [AccountName] NVARCHAR (50)  NOT NULL,
    [Tags]        NVARCHAR (MAX) NOT NULL,
    [Title]       NVARCHAR (50)  NULL,
    [City]        NVARCHAR (100) NULL,
    [Country]     NVARCHAR (50)  NULL,
    [Email]       NVARCHAR (50)  NOT NULL,
    [Password]    NVARCHAR (50)  NOT NULL,
    [Phone]       NVARCHAR (50)  NULL,
    [Position]    NVARCHAR (50)  NULL,
    [Department]  NVARCHAR (250) NULL,
    [DateTime]    DATETIME       NOT NULL,
    [IsActive]    BIT            NOT NULL,
    CONSTRAINT [PK_Expert] PRIMARY KEY CLUSTERED ([ExpertId] ASC)
);

