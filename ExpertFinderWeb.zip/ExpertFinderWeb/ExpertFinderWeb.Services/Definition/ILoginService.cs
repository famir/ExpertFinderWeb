﻿using ExpertFinderWeb.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExpertFinderWeb.Services.Definition
{
    public interface ILoginService
    {
        bool CanAccessApplication(Login userAccount);
    }
}
