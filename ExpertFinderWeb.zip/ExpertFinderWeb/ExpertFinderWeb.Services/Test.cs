﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ExpertFinderWeb.Data.Access.Implementation;

namespace ExpertFinderWeb.Services
{
    public class Test
    {
        public void test()
        {
            var v = new TestClass();
            v.TestMethod();
        }

        
    }
}
