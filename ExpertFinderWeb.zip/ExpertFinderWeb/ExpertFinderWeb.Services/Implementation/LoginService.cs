﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ExpertFinderWeb.Services.Definition;
using ExpertFinderWeb.Model;

namespace ExpertFinderWeb.Services.Implementation
{
    public class LoginService : ILoginService
    {
        public bool CanAccessApplication(Login userAccount)
        {
            return true;
        }
    }
}
