﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ExpertFinderWeb.Model;
using ExpertFinderWeb.Services.Definition;

namespace ExpertFinderWeb.Web.Ui.Controllers
{
    public class LoginController : Controller
    {
        private ILoginService _service { get; set; }

        public LoginController(ILoginService service)
        {
            _service = service;
        }

        // GET: Login
        public ActionResult Index()
        {
            return View(new Login());
        }

        [HttpPost]
        public ActionResult Login(Login login)
        {
            var success = _service.CanAccessApplication(login);
            

                return View("Invalid");
            
        }
    }
}