﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ExpertFinderWeb.Web.Ui.Controllers
{
    public class ExpertOverviewController : Controller
    {
        // GET: ExpertOverview
        public ActionResult Index()
        {
            return View();
        }
    }
}