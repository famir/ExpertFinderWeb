﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ExpertFinderWeb.Web.Ui.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Login()
        {
<<<<<<< HEAD
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page. ";
=======
            ViewBag.Message = "You can log in to the application";
>>>>>>> dc2e91d404a321f401e09c34f7f4dc1b219086b2

            return View();
        }
        
    }
}